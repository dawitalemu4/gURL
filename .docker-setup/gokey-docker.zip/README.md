# Docker Setup

All you need to do run this project with docker is to:

1. Download this folder using the gokey-cURL.zip in this folder and extract it in your preferred location

2. Rename `.env.example` to `.env` and put your own custom values (you can just use the provided values)

3. Run `docker-compose up` in your gokey-cURL directory while your docker engine is running

4. Go to `localhost:YOURPORT` in your browser

Check out [gokey.github.io/shortcuts](https://gokey.github.io/shortcuts) or [shortcuts.md](https://github.com/dawitalemu4/gokey.github.io/blob/main/src/assets/docs/shortcuts.md) for tutorials on how to run the [startup script](https://github.com/dawitalemu4/gokey-cURL/tree/main/.docker-setup/startup.sh) in this folder from a shortcut on your taskbar to easily start up gokey-cURL!

> If the initial `/docker-entrypoint-initdb.d/queries.sql` setup doesn't work, you may need to run `psql -U user -c "CREATE DATABASE gokey;"` and then `psql -U user -d gokey -f '/docker-entrypoint-initdb.d/queries.sql/queries.sql'` inside of the db container's exec tab within docker desktop. 

> Note for mac users: If you are running into this error: `rosetta error: failed to open elf at /lib64/ld-linux-x86-64.so.2`, try to use this flag in the docker file: `FROM --platform=linux/amd64 golang:1.22.2`
